﻿using Schneider.MinesweeperHybrid.Game.Enums;
using Schneider.MinesweeperHybrid.Models;

Console.WriteLine("Start a new game?");
var startGame = Console.ReadLine();

if (startGame.ToLower().StartsWith("y"))
{
    MinesweeperHybridGame game = new MinesweeperHybridGame();
    game.SetStartingCell();

    Console.WriteLine($"{game.GetPlayerPosition()} - Score({game.GetScore()}) - Lives({game.GetLives()})");

    while (game.completed != true && !game.IsGameOver())
    {
        Console.WriteLine("What's your move?");
        var position = Console.ReadLine();

        Enum.TryParse(position?.ToLower(), out MoveType move);
        game.MovePosition(move);
        game.IsGameCompleted();
        Console.WriteLine($"{game.GetPlayerPosition()} - Score({game.GetScore()}) - Lives({game.GetLives()})");
    }

    if (game.IsGameOver())
    {
        Console.WriteLine($"Game Over - You Loose");
    }
    else 
    {
        Console.WriteLine($"whoo hoo - Game complete.  Your score was {game.GetScore()}");
    }
    Console.ReadLine();
}
