ToDo
-------
Fix out of range exceptions.  So if your at A1 and you press left, should prevent it.

