﻿using Schneider.MinesweeperHybrid.Game.Enums;
using Schneider.MinesweeperHybrid.Game.Game;
using Schneider.MinesweeperHybrid.Models.Board;
using Schneider.MinesweeperHybrid.Utilities.Constants;

namespace Schneider.MinesweeperHybrid.Models
{
    public class MinesweeperHybridGame : IGame
    {
        public bool completed = false;
        private DefaultBoard board;
        private Cell currentCell;
        private Score score;
        private Player player;

        public MinesweeperHybridGame() 
        {
            board = new DefaultBoard(GameConstants.DefaultBoardSize);
            currentCell = new Cell(GameConstants.DefaultStartingPos, GameConstants.DefaultStartingPos);
            player = new Player(ref currentCell);
            score = new Score();
        }

        public void SetStartingCell()
        {
            board.SetPosition(currentCell);
        }

        public void MovePosition(MoveType move)
        {
            if (currentCell.Col < board.Size)
            {
                player.MovePosition(move);
                board.SetPosition(currentCell);
                CheckIfCellHasBomb();
            }
        }

        public bool IsGameCompleted()
        {
            completed = currentCell.Col == board.Size;
            return completed;
        }

        public string GetPlayerPosition()
        {
            return player.GetPlayerPosition();
        }

        public bool IsGameOver()
        {
            return player.GetLives() == GameConstants.DefaultZero ? true : false; 
        }

        public int GetScore()
        {
            return score.GetCurrentScore();
        }

        public int GetLives()
        {
            return player.GetLives();
        }

        private void CheckIfCellHasBomb()
        {
            if (!board.HasBomb(currentCell))
                score.UpdateScore();
            else
                player.DecreaseLives();
        }
    }
}
