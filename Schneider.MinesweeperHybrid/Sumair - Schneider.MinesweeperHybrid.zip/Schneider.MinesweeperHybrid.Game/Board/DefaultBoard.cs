﻿using Schneider.MinesweeperHybrid.Game.Board;
using Schneider.MinesweeperHybrid.Utilities.Constants;

namespace Schneider.MinesweeperHybrid.Models.Board
{
    public class DefaultBoard : BaseBoard
    {
        public DefaultBoard(int size) 
        {
            CreateBoard(size, BoardConstants.DefaultNoOfBombs);
        }

        public void SetPosition(Cell cell)
        {
            cell.Occupied = true;
        }

        public bool HasBomb(Cell cell)
        {
            return Grid[cell.Row, cell.Col-1].HasBomb;
        }
    }
}
