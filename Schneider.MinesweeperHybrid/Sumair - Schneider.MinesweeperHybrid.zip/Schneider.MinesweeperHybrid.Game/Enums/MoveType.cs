﻿namespace Schneider.MinesweeperHybrid.Game.Enums
{
    public enum MoveType
    {
        up,

        down,

        left,

        right,
    }
}
