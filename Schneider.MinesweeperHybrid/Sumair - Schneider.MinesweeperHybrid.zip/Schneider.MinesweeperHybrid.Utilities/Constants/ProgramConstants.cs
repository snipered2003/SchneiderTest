﻿namespace Schneider.MinesweeperHybrid.Utilities.Constants
{
    public static class ProgramConstants
    {

    }
}
