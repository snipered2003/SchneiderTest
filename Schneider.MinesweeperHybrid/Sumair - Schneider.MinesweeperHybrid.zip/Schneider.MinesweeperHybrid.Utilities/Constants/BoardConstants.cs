﻿namespace Schneider.MinesweeperHybrid.Utilities.Constants
{
    public static class BoardConstants
    {
        public const int DefaultRandomMin = 2;

        public const int DefaultNoOfBombs = 50;
    }
}
