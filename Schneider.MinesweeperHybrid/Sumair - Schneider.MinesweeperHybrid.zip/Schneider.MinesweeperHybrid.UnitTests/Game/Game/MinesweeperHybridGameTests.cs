﻿using Schneider.MinesweeperHybrid.Game.Enums;
using Schneider.MinesweeperHybrid.Models;

namespace Schneider.MinesweeperHybrid.UnitTests.Game.Game
{
    public class MinesweeperHybridGameTests
    {

        [Theory]
        [InlineData(MoveType.up)]
        [InlineData(MoveType.right)]
        public void CheckIfGameIsCompleted_ReturnsFalse(MoveType move)
        {
            //Arrange
            var game = CreateStrut();

            //Act
            game.MovePosition(move);

            //Assert
            Assert.False(game.IsGameCompleted());
        }

        [Fact]
        public void CheckIfGameIsCompleted_ReturnsTrue()
        {
            //Arrange
            var game = CreateStrut();

            //Act
            for (var i = 0;i < 7; i++) 
            {
                game.MovePosition(MoveType.up);
            }

            //Assert
            Assert.True(game.IsGameCompleted());
        }

        [Fact]
        public void GetPlayerPosition_ReturnsCorrectPosition()
        {
            //Arrange
            var game = CreateStrut();
            var expectedOutcome = "[A2]";

            //Act
            game.MovePosition(MoveType.up);
            var position = game.GetPlayerPosition();

            //Assert
            Assert.Equal(expectedOutcome, position);
        }

        [Fact]
        public void GetScore_ReturnsCorrectly()
        {
            //Arrange
            var game = CreateStrut();
            var expectedScore = 2;

            //Act
            game.MovePosition(MoveType.up);
            game.MovePosition(MoveType.right);
            int score = game.GetScore();

            //Assert
            Assert.Equal(expectedScore, score);
        }

        [Fact]
        public void GetLives_ReturnsCorrectly()
        {
            //Arrange
            var game = CreateStrut();
            var expectedLives = 3;

            //Act
            game.MovePosition(MoveType.up);
            game.MovePosition(MoveType.right);
            int lives = game.GetLives();

            //Assert
            Assert.Equal(expectedLives, lives);
        }

        private MinesweeperHybridGame CreateStrut()
        {
            var game = new MinesweeperHybridGame();
            game.SetStartingCell();
            return game;
        }

       
    }
}
